import sqlalchemy as db
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from models import *
from pathlib import Path

Path("database").mkdir(exist_ok=True)
engine = create_engine("sqlite:///database/main.db", echo=False)
Base.metadata.create_all(engine)

# +++++++++++ user functions +++++++++++ #
def insert_user(username: str, password: str):
    with Session(engine) as session:
        user = User(username=username, password=password)
        session.add(user)
        session.commit()


def get_user(username: str):
    with Session(engine) as session:
        return session.get(User, username)

# +++++++++++ Friendship Functions +++++++++++ #
def save_friend(user1: str, user2: str):
    with Session(engine) as session:
        friend1 = Friend(user_username1=user1, user_username2=user2)
        friend2 = Friend(user_username1=user2, user_username2=user1)
        session.add_all([friend1, friend2])
        session.commit()


def get_friend(user: str, user2: str):
    with Session(engine) as session:
        friend = session.query(Friend).filter_by(user_username1=user, user_username2=user2).first()
        if not friend:
            friend = session.query(Friend).filter_by(user_username2=user, user_username1=user2).first()
        return friend


def get_friend_list(username: str):
    with Session(engine) as session:
        friends = session.query(Friend).filter_by(user_username1=username).all()
        return [friend.user_username2 for friend in friends]

# +++++++++++ Friend Request Functions +++++++++++ #
def save_friend_request(sender: str, receiver: str):
    with Session(engine) as session:
        friend_request = FriendRequest(sender_username=sender, receiver_username=receiver)
        session.add(friend_request)
        session.commit()
        return True


def get_friend_request(sender: str, receiver: str):
    with Session(engine) as session:
        return session.query(FriendRequest).filter_by(sender_username=sender, receiver_username=receiver).first()


def update_friend_request(sender: str, receiver: str, status: str):
    with Session(engine) as session:
        friend_request = session.query(FriendRequest).filter_by(sender_username=sender,
                                                                receiver_username=receiver).first()
        if friend_request:
            friend_request.status = status
            session.commit()
            return True
        return False


def get_friend_request_list(user: str):
    with Session(engine) as session:
        requests = session.query(FriendRequest).filter_by(receiver_username=user).all()
        return [f"{request.sender_username}, status: {request.status}" for request in requests]

# +++++++++++ Message Functions +++++++++++ #
def save_message(roomid: int, sender: str, receiver: str, message: str):
    with Session(engine) as session:
        chat_msg = ChatRecord(chatroom_id=roomid, sender_username=sender, receiver_username=receiver, message=message)
        session.add(chat_msg)
        session.commit()
        return True


def get_message_list(sender: str, receiver: str):
    with Session(engine) as session:
        db_room_id = get_room(sender, receiver)
        chat_records = session.query(ChatRecord).filter_by(chatroom_id=db_room_id).all()
        return [{"sender": msg.sender_username, "content": msg.message} for msg in chat_records]

def delete_all_chat_data():
    """Delete all data from ChatRoom and ChatRecords tables."""
    with Session(engine) as session:
        try:
            # Delete all records in ChatRecords first due to foreign key constraints
            session.query(ChatRecord).delete()
            # Then delete all records in ChatRoom
            session.query(RoomDB).delete()
            session.commit()
            print("All data in ChatRoom and ChatRecords have been deleted.")
        except Exception as e:
            session.rollback()
            print(f"Failed to delete data: {e}")
if __name__ == "__main__":
    delete_all_chat_data()